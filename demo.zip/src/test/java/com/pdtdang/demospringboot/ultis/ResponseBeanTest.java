package com.pdtdang.demospringboot.ultis;

import static org.junit.jupiter.api.Assertions.*;

class ResponseBeanTest {

}