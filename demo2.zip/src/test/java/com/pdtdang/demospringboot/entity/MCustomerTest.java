package com.pdtdang.demospringboot.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MCustomerTest {

    @Test
    void getId() {
    }

    @Test
    void setId() {
    }
}