package com.pdtdang.demospringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemospringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
