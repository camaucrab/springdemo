package com.pdtdang.demospringboot.responsitories;

import static org.junit.jupiter.api.Assertions.*;

class CustomerResponsitoryTest {

}